<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/stylesheet.css">
		<link rel="stylesheet" type="text/css" href="css/animate.css">

	  <!-- <link rel="stylesheet" href="css/bootstrap-select.css"> -->
	<title>TechAdvance </title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

	<script type="text/javascript" src="js/bootstrap.js"></script>
	<link rel="stylesheet" href="http://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">

	  <script type='text/javascript' src='js/jquery.particleground.js'></script>
  <script type='text/javascript' src='js/demo.js'></script>

  <link href="https://fonts.googleapis.com/css?family=Oswald:460|Heebo|Hind|Lato:900" rel="stylesheet">

	 	      <script src="js/script.js"></script>
	    <script src="js/typed.js" type="text/javascript"></script>


	    <script>
    document.addEventListener('DOMContentLoaded', function(){

        Typed.new("#typed", {
            stringsElement: document.getElementById('typed-strings'),
            typeSpeed: 130,
            backDelay: 600,
            loop: true,
            contentType: 'html', // or text
            // defaults to null for infinite loop
            loopCount: null,
            callback: function(){ foo(); },
            resetCallback: function() { newTyped(); }
        });

        var resetElement = document.querySelector('.reset');
        if(resetElement) {
            resetElement.addEventListener('click', function() {
                document.getElementById('typed')._typed.reset();
            });
        }

    });

    function newTyped(){ /* A new typed object */ }

    function foo(){ console.log("Callback"); }

    </script>

	<style type="text/css">
		.navbar-default{
			background: none;
			border:none;
		}
	</style>

</head>
<body>

	<div id="particles">
		<div id="header"> 
			<div class="container-fluid">
			 <div class="row">
				<div class="col-md-3">
					<img src="img/techadvance_logo.png" class="logo animated shake" >
				</div>
			</div>

			<div class="row">
				<div class="col-md-6">
					
					<div id="home-box" style="margin-top:28%">
						
						<div class="type-wrap">
							<h2 class="">BUILDING & INVESTING <br/> IN SUSTAINABLE</h2>
						 <span style="color:#ffb026" id="typed-strings"><h2>TECHNOLOGY</h2></span>

       				 <span id="typed" style="white-space:pre;"></span> </div>
					</div>
				</div>
				<div class="col-md-6">
					<p align="right">
					<img src="img/desktop2.png" width="100%" class="animated bounceIn" style="margin-right: -20%">
				</p>
				</div>
			</div>

				
			</div>
		</div>
		

	</div>

	<div id="about-us">

		<div id="youtube-box" class="">
			<iframe width="100%" height="100%" src="https://www.youtube.com/embed/xSicnksyEaA?start=6" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
		</div>

			<div class="col-md-6 col-sm-12 col-xs-12" style="margin-top:7%">
				<div class="container-fluid">

				<h2 style="margin-bottom:6%">MEET TECHADVANCE</h2>
				<p>TechAdvance is a payment application development company with a strategic focus in developing and deploying niche payment companies to serve the needs of large public and private sector organisations in Nigeria.</p>
				<p> <br />

TechAdvance has subsidiaries across the IGR, Utilities, Finance and Transport Space in Nigeria.</p>
			</div>
		</div>
			<div class="col-md-6 hidden-sm hidden-xs" style="padding-right:0px">
			
				<div class="col-md-6  social animated flipInX">
					<h3 align="center">SOCIAL MEDIA</h3>
					<p align="center">
					<img src="img/fb.jpg" width="10%">
					<img src="img/twitter.jpg" width="10%">
					<img src="img/instagram.jpg" width="10%">
					<img src="img/linkedin.jpg" width="10%">
				</p>
				</div>
				<div class="col-md-6 youtube animated bounceInRight">
					<p align="center">
						<img src="img/play.png" style="margin-top:16%; width: 50%; cursor: pointer">
					</p>
				</div>
			
				<div class="col-md-12 box-team animated zoomIn">
					<h2 align="center">OUR TEAM</h2>
				</div>

			</div>

		</div>	
	</div>

	

	<div id="service">

		<div class="container-fluid">

			<div class="col-md-5">
				<h2 style="margin-top:18%">OUR SERVICE <img src="img/ta-link.png" width="6%" style="margin-top:-10px; margin-left:5%"></h2>
				<p>
					We are a software development and outsourcing company. We pride in our expertise at implementing procedures to ensure that all your techology needs are met in a reasonable timeframe, reasonable cost and with the least amount of downtime. We offer well-balanced creative technology services and build solutions to suit your ideas perfectly
				</p>

				<div class="service-box">
					<img src="img/application-icon.svg" style="width: 10%; margin-bottom: 1%">
					<p>Application Development</p>
					<img src="img/plus.svg" style="float: right; margin-top:-54px">
				</div>
				<div class="service-box">
					<img src="img/product-icon.svg" style="width: 10%; margin-bottom: 1%">
					<p>Product Strategy</p>
					<img src="img/plus.svg" style="float: right; margin-top:-54px">
				</div>
				<div class="service-box">
					<img src="img/data-icon.svg" style="width: 10%; margin-bottom: 1%">
					<p>Analytics & Big Data</p>
					<img src="img/plus.svg" style="float: right; margin-top:-58px">
				</div>
			</div>

			<div class="col-md-7">
				<img src="img/portfolio_landing_bg.png" width="80%" style="float: right; margin-top:24%" class="animated slideInRight">
				<img src="img/edo.png" width="80%" style="float: right; margin-top: -90%;
margin-right: -140px;" class="animated slideInRight">
			</div>

		</div>		
	</div>


<footer>
	
          <div class="container-fluid">
          
          <h2 align="center">TechAdvance</h2>
          <p align="center">Committed to building and investing in substainable transaction <br />technologies for emerging marketing <br /> <br /><a href="contact.html"><button class="btn btn-large btn-info" style="padding: 1% 5%; font-family: 'Lato'; background: #14a0e7; font-size: 20px; box-shadow: 5px 5px 10px #ccc">contact us</button></a></p>
          

          	<img src="img/team-banner.jpg" width="100%">
          	<hr / style="margin: 0px;">
          <div class="row">
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                <h3>Subsidiaries</h3>
                <ul style="padding: 0%;">
                    <li> <a href="http://www.gpayafrica.com/" target="_blank">Gpay Africa</a></li>
                    <li>  Ace Remmittance</li>
                     <li> Data Analytics</li>
                     <li> Transfer2Africa</li>
                    
                </ul>
            </div>
             <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                <h3>Platforms</h3>
                 <ul style="padding: 0%;">
                    <li>  Bills.com.ng</li>
                     <li><a href="https://www.payelectricitybills.com" target="_blank"> Pay Electricity Bills</a></li>
                     <li><a href="https://bus.com.ng" target="_blank">  Bus.com.ng </a></li>
                     <li> Business in the box</li>
                    
                </ul>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                <h3>About us</h3>
                <ul style="padding: 0%;">
                    <li> <a href="team.html">  Team members </a></li>
                     <li> Career</li>
                     <li> <a href="privacy-policy.html">Privacy Policy</a> </li>
					  <li> Staff Portal</li>
                </ul>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                  <h3>Contact us</h3>
                  <ul style="padding: 0%;">
                    <li>  Address:   21c Akin Ogunlewe Street, Off Ligali Ayorinde V/I, Lagos </li>
                     <li> email: info@techadvance.ng</li>
                     <li> Tel: 0709-939-1931</li>
                </ul>
            </div>
          </div>

          <hr />


            <p align="center" style="font-size: 14px"> &copy; 2014 Copyright | Allright reserve</p>

          </div>
      </footer>



	<nav class="animate">
    <p>Mouse0270 created this snippet on <strong>Bootsnipp</strong> network.</p>
    <ul>
        <li>
            <a href="https://twitter.com/mouse0270">@mouse0270 on twitter</a>
        </li>
        <li>
            <a href="https://facebook.com/rem.mcintosh">Learn More about me on Facebook</a>
        </li>
        <li>
            <a href="http://bootsnipp.com/mouse0270">Snippets</a>
        </li>
        <li>
            <a href="https://github.com/mouse0270">Projects</a>
        </li>
        <li>
            <a href="http://bootsnipp.com/user/snippets/www.linkedin.com/in/remcintosh/">Résumé</a>
        </li>
    </ul>
    <div class="divider"></div>
    <h4>Thanks To</h4>
    <ul>
        <li>
            <a href="https://twitter.com/BootSnipp">@BootSnipp on twitter</a>
            <a href="https://twitter.com/Svbtle">@Svbtle on twitter</a>
        </li>
    </ul>
</nav>

<div class="nav-controller">
    <span class="[ glyphicon glyphicon glyphicon-align-justify ] controller-open"></span>
    <span class="[ glyphicon glyphicon-remove ] controller-close"></span>
</div>

<script type="text/javascript">
	$(function() {
    $('nav, .nav-controller').on('click', function(event) {
        $('nav').toggleClass('focus');
    });
    $('nav, .nav-controller').on('mouseover', function(event) {
        $('nav').addClass('focus');
    }).on('mouseout', function(event) {
        $('nav').removeClass('focus');
    });

   

    	    	$('#youtube-box').hide()
    	    $('.youtube').on('click', function(){
    	    	$('#youtube-box').show();
    	    	$('#youtube-box').addClass('animated slideInRight');
    	    	
    	    })

    	     var isChrome = !!window.chrome && !!window.chrome.webstore;

    if(isChrome){

    	$("#about-us").css('position', "relative");
    	$("#about-us").css('min-height', "600px");

    	    
    	    }

    	})
    	</script>
    	
    	</body>'
</html>