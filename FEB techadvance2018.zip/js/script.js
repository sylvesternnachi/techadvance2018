$(window).ready(function(){

	$(window).scroll(function(e){
			//alert('scroll');

			var scroll =  $(this).scrollTop();

			if(scroll >= 1400){
				$("#lady-fone").css('transform','translateX(0px)');
				
			}
			if(scroll >= 2400){
				$("#lady-fone").css('transform','translateX(-600px)');

			}

			

			if(scroll >= 1200){
				//$("#shape").css('display','block');
				$("#shape").css('transform','translateX(0px)');

			}

			if(scroll >= 2400){
				//$("#shape").css('display','block');
				$("#shape").css('transform','translateX(800px)');

			}


			if(scroll >= 1550){
				$("#current-div").css('transform','translateX(0px)');
			}

			console.log(scroll);
	});


});