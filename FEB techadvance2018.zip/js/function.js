$(document).ready(function(){


		//$('.product-box').hide();

	$('.tab-links').on('click', function(e){
		 e.preventDefault(); // ANCHOR DISABLE

		var element =  $(this).data('box');
		$('.tab-links').not($(this)).removeClass('active');


		$('.product-box').hide();
		$('#'+element).show();

		$(this).addClass('active');

	})



});